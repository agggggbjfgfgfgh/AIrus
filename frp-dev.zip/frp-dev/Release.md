### Features

* Support metadatas and annotations in frpc proxy commands.

### Fixes

* Properly release resources in service.Close() to prevent resource leaks when used as a library.
